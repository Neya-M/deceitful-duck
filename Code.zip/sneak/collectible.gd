extends Area2D

var touching_player = false
var counter = 0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_body_entered(body: Node2D) -> void:
	if body.name == "player" || body.name == "Collectible-Detecter":
		touching_player = true
	print(body.name)

func _input(event):
	if Input.is_key_pressed(KEY_SPACE) && touching_player:
		queue_free()
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) && touching_player:
		counter += 1
		if counter >= 5:
			$image.texture = load("res://sneak/shiba.png")

func _on_body_exited(body: Node2D) -> void:
	if body.name == "player" || body.name == "Collectible-Detecter":
		touching_player = false
	print(body.name)
