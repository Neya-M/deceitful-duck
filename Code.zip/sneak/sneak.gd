extends Node2D

var borders = Rect2(1, 1, 38, 21)
var duck_type = 1
var health = 3

@onready var tileMap = $walls
@onready var Collectibles = $Collectibles

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	randomize()
	generate_level()

func generate_level():
	var walker = Walker.new(Vector2(2, 21), borders)
	var exit_walker = Walker.new(Vector2(38, 2), borders)
	var map = walker.walk(500)
	var exit_map = exit_walker.walk(500)
	walker.queue_free()
	for location in map[0]:
		var pos = Vector2i(location.x, location.y)
		tileMap.set_cells_terrain_connect([pos], 0, -1)
	for location in exit_map[0]:
		var pos = Vector2i(location.x, location.y)
		tileMap.set_cells_terrain_connect([pos], 0, -1)
	for location in map[1]:
		var scene = preload("res://sneak/Collectible.tscn")
		var collectible = scene.instantiate()
		Collectibles.add_child(collectible)
		var atlas_texture = AtlasTexture.new()
		atlas_texture.atlas = load("res://sneak/items.png")
		var random = randi_range(0, 1) * 12
		print(random)
		atlas_texture.region = Rect2(Vector2(random, duck_type * 12), Vector2(12, 12))
		collectible.get_node("image").texture = atlas_texture
		var scale = 16
		collectible.position = Vector2i(location.x * scale + 8, location.y * scale + 8)


func _on_button_pressed() -> void:
	randomize()
	generate_level()

func less_health():
	health -= 1
	if health == 2:
		$player/Health4.hide()
	elif health == 1:
		$player/Health3.hide()
	else:
		$player/Health2.hide()
