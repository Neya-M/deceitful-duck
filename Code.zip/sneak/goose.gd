extends Area2D

@onready var scope = $scope
@onready var level = $".."
@onready var animation = $Animation
var colliding = false
var direction = randi_range(0, 3)
var remaining_directions = [0, 1, 2, 3]
var directionKey = [Vector2(0.5, 0), Vector2(-0.5, 0), Vector2(0.5, 1), Vector2(0.5, -1)]
var rotationKey = [180, 0, 270, 90]


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	animation.play("walk")

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if randi_range(0, 50) == 3:
		direction = randi_range(0, 3)
	move_goose()
	scope.rotation_degrees = rotationKey[direction]

func move_goose():
	self.position += directionKey[direction]
	if "walls" in str(get_overlapping_bodies()):
		self.position -= directionKey[direction]
		remaining_directions.erase(direction)
		print(remaining_directions)
		print(direction)
		if len(remaining_directions) > 0:
			direction = randi_range(0, len(remaining_directions)-1)
			direction = remaining_directions[direction]
			move_goose()
		else:
			print("stuck")
	if direction == 0:
		animation.flip_h = true
	else:
		animation.flip_h = false

func _on_body_entered(body: Node2D) -> void:
	if body.name == "walls":
		colliding = true

func _on_scope_body_entered(body: Node2D) -> void:
	if body.name == "player":
		animation.play("LE HONK")
		level.less_health()


func _on_body_exited(body: Node2D) -> void:
	if body.name == "walls":
		colliding = false



func _on_scope_body_exited(body: Node2D) -> void:
	if body.name == "player":
		animation.play("walk")
