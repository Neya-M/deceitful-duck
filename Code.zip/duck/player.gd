extends CharacterBody2D


const SPEED = 100.0
@onready var animation = $AnimatedSprite2D

func _physics_process(delta: float) -> void:
	var x_direction := Input.get_axis("left", "right")
	if x_direction:
		velocity.x = x_direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
	
	var y_direction := Input.get_axis("up", "down")
	if y_direction:
		velocity.y = y_direction * SPEED
	else:
		velocity.y = move_toward(velocity.y, 0, SPEED)
	move_and_slide()
	if velocity.x < 0:
		animation.flip_h = true
	elif velocity.x > 0:
		animation.flip_h = false
	if velocity.x != 0:
		animation.play("t"+"Run")
	elif velocity.y != 0:
		animation.play("t"+"RunBehind")
	else:
		animation.frame = 0
